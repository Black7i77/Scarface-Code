/**
 * Automatically generated file. DO NOT MODIFY
 */
package io.github.rosemoe.sora.langs.textmate;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "io.github.rosemoe.sora.langs.textmate";
  public static final String BUILD_TYPE = "release";
}
